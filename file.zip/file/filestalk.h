
#ifndef FILESTALK_H

#define FILESTALK_H


void ignore();

void *peertalk(void* args);
void *listening(void* args);





#endif